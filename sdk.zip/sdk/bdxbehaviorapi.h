#include <string>
#include <iostream>
#include <functional>
using namespace std;
typedef unsigned long long xuid_t;
#define BDXLog_API __declspec(dllexport)

#ifndef LBPCH_H
class Vec3 {
public:
	float x, y, z;
	string toString() {
		return "(" + std::to_string(x) + "," + std::to_string(y) + "," + std::to_string(z) + ")";
	}
};
class BlockPos {
public:
	int x, y, z;
	inline bool operator==(BlockPos const& rv)const {
		return x == rv.x && y == rv.y && z == rv.z;
	}
	inline bool operator!=(BlockPos const& rv)const {
		return x != rv.x || y != rv.y || z != rv.z;
	}
};
#endif

class JoinEV {
public:
#ifdef LBPCH_H
	WPlayer WPlayerOri;
#endif
	string playername;
	int DimId;
	string IP;
	xuid_t xuid;
};
class ContainerInEV {
public:
#ifdef LBPCH_H
	Player* PlayerOri;
	ItemStack* ItemStackOri;
#endif
	string playername;
	int DimId;
	int slot;
	int Count;
	string object_name;
};
class ContainerOutEV {
public:
#ifdef LBPCH_H
	Player* PlayerOri;
	ItemStack* ItemStackOri;
#endif
	string playername;
	int DimId;
	int slot;
};
class BlockPlacedEV {
public:
#ifdef LBPCH_H
	Player* PlayerOri;
	const Block* BlockOri;
#endif
	string playername;
	const BlockPos* Pos;
	int DimId;
	string BlockName;
};

class BlockDestroyedEV {
public:
#ifdef LBPCH_H
	Player* PlayerOri;
	const Block* BlockOri;
#endif
	string playername;
	const BlockPos* Pos;
	int DimId;
	string BlockName;
};
class MobDieEV {
public:
#ifdef LBPCH_H
	Mob* DieMob;
	Actor* SrcActor;
#endif
	string SrcTypeName;
	string SrcNameTag;
	string TargetTypeName;
	string TargetNameTag;
	string DieReason;
	string DieCode;
	Vec3 Pos;
};
class ItemDropEV {
public:
#ifdef LBPCH_H
	Player* PlayerOri;
	ItemStack* ItemStackOri;
#endif
	string playername;
	string ItemName;
	string DropCount;
	Vec3 Pos;
	int DimId;
};
class ItemTakeEV {
public:
#ifdef LBPCH_H
	Player* PlayerOri;
	Actor* ItemOri;
#endif
	string playername;
	string ItemName;
	Vec3 Pos;
	int DimId;
};
enum CommandBlockType {
	CommandBlock = 1,
	CommandBlockMineCrat = 2
};
class CommandBlockUpdateEV {
public:
#ifdef LBPCH_H
	Player* PlayerOri;
#endif

	string playername;
	Vec3 Pos;
	string Command;
	CommandBlockType Type ;//1 for commandBlock, 2for commandMinerat
};

namespace BLogApi {
	BDXLog_API void addBehavorListener(function<void(JoinEV)> callback);
	BDXLog_API void addBehavorListener(function<void(ContainerOutEV)> callback);
	BDXLog_API void addBehavorListener(function<void(ContainerInEV)> callback);
	BDXLog_API void addBehavorListener(function<void(MobDieEV)> callback);
	BDXLog_API void addBehavorListener(function<void(ItemDropEV)> callback);
	BDXLog_API void addBehavorListener(function<void(ItemTakeEV)> callback);
	BDXLog_API void addBehavorListener(function<void(CommandBlockUpdateEV)> callback);
	BDXLog_API void addBehavorListener(function<void(BlockPlacedEV)> callback);
	BDXLog_API void addBehavorListener(function<void(BlockDestroyedEV)> callback);
	BDXLog_API pair<bool, string> Runcmd(const string& str);
};
