#include <iostream>
#include <lbpch.h>
#include "pch.h"
#include <api/Loader.h>
#include <api/MC.h>
#include <mcapi/Player.h>
#include <rapidjson/document.h>
#include<streambuf>
#include<api/command/commands.h>
#include<api/types/types.h>
#include<api/event/event_pch.h>
#include "Helper.h"


int _access(const char
	* path, int mode);
using namespace std;
#pragma warning(disable:4996)
inline string gettime()
{
	time_t rawtime;
	tm* LocTime;
	char timestr[20];
	time(&rawtime);
	LocTime = localtime(&rawtime);
	strftime(timestr, 20, "%Y-%m-%d %H:%M:%S", LocTime);
	return string(timestr);
}
inline void fw(const string& filen, const string& instr)
{
	if (filen == "config\\Elevator.json")
		return;
	if ((_access(filen.c_str(), 0)) != -1)
	{
		ofstream outfile;
		outfile.open(filen, ios::app);
		if (!outfile)
		{
			cout << "[" << gettime() << u8" INFO] FileWriteFailed!!!" << endl;
		}
		outfile << instr << endl;
		outfile.close();
	}
	else
	{
		std::ofstream outfile(filen);
		if (!outfile)
		{
			cout << "[" << gettime() << u8" INFO] FileWriteFailed!!!" << endl;
		}
		unsigned char bom[] = { 0xEF, 0xBB, 0xBF };
		outfile.write((char*)bom, sizeof(bom));
		outfile.close();
		fw(filen, instr);
	}
}
rapidjson::Document config;
void loadconfig() {
	ifstream in("config\\Elevator.json");
	ostringstream tmp;
	tmp << in.rdbuf();
	in.close();
	string data = tmp.str();
	config.Parse(data.c_str());
	int size = config.Size();
	if (size == 0)
		cout << "[" << gettime() << u8" Error] No Member Found!!!" << endl;
}


using namespace std;
THook(bool, "?startDestroyBlock@GameMode@@UEAA_NAEBVBlockPos@@EAEA_N@Z",
	void* _this, BlockPos* a2, char* a3, bool* a4) {
	auto sp = *reinterpret_cast<Player**>(reinterpret_cast<unsigned long long>(_this) + 8);
	auto playername = sp->getNameTag();
	Vec3 playerPos = sp->getPos();
	auto pl = WPlayer(*(ServerPlayer*)sp);
	int px = playerPos.x;
	int py = playerPos.y;
	int pz = playerPos.z;
	auto bx = a2->x;
	auto by = a2->y;
	auto bz = a2->z;
	bool ifFind = false;
	__int64 v3 = *((__int64*)_this + 26);
	BlockSource* bs = *(BlockSource**)(*(__int64*)(v3 + 848) + 88i64);
	Block* pBlk = SymBlockSource::getBlock(bs, a2);
	string bname = offBlock::getFullName(pBlk);
	string pname = config["eBlockName"].GetString();
	std::cout<< pname <<endl;
	if (pname == bname && bx == px && bz == pz)
	{
		auto maxUpDis = config["maxUpDis"].GetInt();
		for (auto i = 1; i <= maxUpDis; i++) {
			Block* tblock = fuck::getBlock(bs, bx, by + 1, bz);
			string testbname = offBlock::getFullName(tblock);
			if (testbname == bname) {
				BDX::runcmdEx("playsound tile.piston.in @a[name=\"" + playername + "\"] " + std::to_string(bx) + " " + std::to_string(by) + " " + std::to_string(bz) + " 1 1");
				auto pcmp = sp->getPos();
				int m = pcmp.y;
				auto q = m - i + 1;
				Vec3 pcmp2 = { pcmp.x ,q, pcmp.z };
				pl.teleport(pcmp2, pl->getDimensionId());
				BDX::runcmdEx("playsound tile.piston.out @a[name=\"" + playername + "\"] " + std::to_string(bx) + " " + std::to_string(by - i + 1) + " " + std::to_string(bz) + " 1 1");
				i = maxUpDis + 1;
				bool ifFind = true;
			}
		}
		if (!ifFind) {
			pl.sendText("δ���·��ҵ����ݷ���");
		}
	}
}

THook(bool, "?startBuildBlock@GameMode@@UEAAXAEBVBlockPos@@E@Z",
	void* _this, BlockPos* a2, char* a3) {
	auto sp = *reinterpret_cast<Player**>(reinterpret_cast<unsigned long long>(_this) + 8);
	auto playername = sp->getNameTag();
	Vec3 playerPos = sp->getPos();
	auto pl = WPlayer(*(ServerPlayer*)sp);
	int px = playerPos.x;
	int py = playerPos.y;
	int pz = playerPos.z;
	auto bx = a2->x;
	auto by = a2->y;
	auto bz = a2->z;
	bool ifFind = false;
	__int64 v3 = *((__int64*)_this + 26);
	BlockSource* bs = *(BlockSource**)(*(__int64*)(v3 + 848) + 88i64);
	Block* pBlk = SymBlockSource::getBlock(bs, a2);
	string bname = offBlock::getFullName(pBlk);
	string pname = config["eBlockName"].GetString();
	if (pname == bname && bx == px && bz == pz)
	{
		auto maxUpDis = config["maxUpDis"].GetInt();
		for (auto i = 1; i <= maxUpDis; i++) {
			Block* tblock = fuck::getBlock(bs, bx, by - 1, bz);
			string testbname = offBlock::getFullName(tblock);
			if (testbname == bname) {
				BDX::runcmdEx("playsound tile.piston.in @a[name=\"" + playername + "\"] " + std::to_string(bx) + " " + std::to_string(by) + " " + std::to_string(bz) + " 1 1");
				auto pcmp = sp->getPos();
				int m = pcmp.y;
				auto q = m + i + 1;
				Vec3 pcmp2 = { pcmp.x ,q , pcmp.z };
				pl.teleport(pcmp2, pl->getDimensionId());
				BDX::runcmdEx("playsound tile.piston.out @a[name=\"" + playername + "\"] " + std::to_string(bx) + " " + std::to_string(by + i + 1) + " " + std::to_string(bz) + " 1 1");
				i = maxUpDis + 1;
				bool ifFind = true;
			}
		}
		if (!ifFind) {
			pl.sendText("δ���Ϸ��ҵ����ݷ���");
		}
	}
}
void entry() {
	loadconfig();
	cout << "[BDXHunter] BDXHunter Loaded, By DreamGuXiang, Build Date [" << __TIMESTAMP__ << u8"] @FineServerحiFine " << endl;
}
